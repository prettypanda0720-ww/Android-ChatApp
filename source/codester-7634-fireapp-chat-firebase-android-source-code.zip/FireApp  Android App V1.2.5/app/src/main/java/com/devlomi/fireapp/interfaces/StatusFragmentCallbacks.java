package com.devlomi.fireapp.interfaces;

public interface StatusFragmentCallbacks {
    void openCamera();

    void fetchStatuses();
}
