package com.devlomi.fireapp.model.constants;

public class LastSeenStates {
    public static int ONLINE = 1;
    public static int LAST_SEEN = 2;

}
