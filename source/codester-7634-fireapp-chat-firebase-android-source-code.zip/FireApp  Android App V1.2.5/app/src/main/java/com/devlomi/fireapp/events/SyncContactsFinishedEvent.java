package com.devlomi.fireapp.events;

public class SyncContactsFinishedEvent {
}
