package com.devlomi.fireapp.interfaces;

/**
 * Created by Devlomi on 18/12/2017.
 */

public interface ToolbarStateChange {
    void hideToolbar();
    void showToolbar();
    void toggle();
}
