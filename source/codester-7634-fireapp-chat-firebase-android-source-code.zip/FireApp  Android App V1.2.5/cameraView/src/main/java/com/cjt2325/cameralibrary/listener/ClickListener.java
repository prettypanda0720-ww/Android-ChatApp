package com.cjt2325.cameralibrary.listener;

/**
 * =====================================
 * 作    者: 陈嘉桐
 * 版    本：1.1.9
 * 创建日期：2017/10/7
 * 描    述：
 * =====================================
 */
public interface ClickListener {
    void onClick();
}
