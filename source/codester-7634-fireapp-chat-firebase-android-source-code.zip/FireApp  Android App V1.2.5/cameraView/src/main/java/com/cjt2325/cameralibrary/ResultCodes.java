package com.cjt2325.cameralibrary;

/**
 * Created by Devlomi on 31/10/2017.
 */

public class ResultCodes {
    public static final int IMAGE_CAPTURE_SUCCESS = 101;
    public static final int VIDEO_RECORD_SUCCESS = 102;
    public static final int CAMERA_ERROR_STATE = 103;
    public static final int PICK_IMAGE_FROM_CAMERA = 104;


}
